package com.spring.cloud.sleuth.zuul.main;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SleuthZuulApplicationTests {

    @Test
    public void contextLoads() {
    }

}

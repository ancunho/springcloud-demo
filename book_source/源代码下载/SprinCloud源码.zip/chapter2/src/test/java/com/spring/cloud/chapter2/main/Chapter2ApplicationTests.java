package com.spring.cloud.chapter2.main;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter2ApplicationTests {

    void contextLoads() {
    }

}

package com.spring.cloud.sso.client1.main;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SsoClient1ApplicationTests {

	@Test
	public void contextLoads() {
	}

}
